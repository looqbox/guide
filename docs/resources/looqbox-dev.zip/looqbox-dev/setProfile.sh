#! /usr/bin/env bash

# == Set info == #
R_home=$(Rscript -e 'cat(R.home())')
R_profile=$R_home"/etc/Rprofile.site"

# == Append LOOQBOX_HOME to the Rprofile.site file == #
sudo echo \
'#-----
message("Loading Rprofile for Looqbox")
options("LOOQBOX_HOME" = "~/looqbox-dev/config")
#-----' >> $R_profile

# Problems with gfortran: needs version 4.8

# Correct R variables (in some cases)
# echo \
# 'FLIBS=""
# F77="gfortran-4.8"
# FC="gfortran-4.8"' >> ~/.R/Makevars

# == Update R with Java
R CMD javareconf

# == Install the looqbox package == #
R -e 'install.packages("looqbox", repos = "https://s3-sa-east-1.amazonaws.com/looqbox/Rpackages")'
