library("looqbox")

#-----------------------------------------------------------------------------#
#---  Example function - MODELO
#-----------------------------------------------------------------------------#
get.exampleDataFrame <- function() {
  data.frame(color = c("red", "blue"), value = c(20, 58), stringsAsFactors = FALSE)
}

#-----------------------------------------------------------------------------#
#---  Connections
#-----------------------------------------------------------------------------#

client.mongoString <- "mongodb://looqboxapp:p0ntit0prod@191.232.35.243:27017/looqbox"
client.elasticString <- "http://191.232.184.153:9200"

#-----------------------------------------------------------------------------#
#---  Client Function - getProductByDescription
#-----------------------------------------------------------------------------#
looq.client.getProduto <- function(produto, topLimit=25){
  
  produto <- trimws(produto)
  produto <- gsub("\\b(de|do|da)\\b","", produto)
  produto <- gsub("\\s+"," ", produto)
  produto <- gsub(" ","\" and \"", paste0("\"",produto,"\""))
  
  sql <- paste("
               SELECT top",topLimit,"[COD_PRODUTO] as PLU
               --, ISNULL(COD_PRODUTO_SIMILAR,'')
               , [DESCRICAO] as [Descricao]
               ,[CLASSIF_PRODUTO] as ABC
               ,FORA_LINHA as FL
               FROM [BI].[dbo].[BI_CAD_PRODUTO]
               WHERE 1=1
               and CONTAINS(descricao,`1`)
               --and FORA_LINHA = 'N'
               order by CLASSIF_PRODUTO
               ")
  
  conn = looq.conn("base13")
  r <- looq.sqlExecute(conn, sql,list(produto))
  r
}

#r <- looq.client.getProduto("casd aisjd aisjd iajsd oca cola")
#r$rows

#-----------------------------------------------------------------------------#
#---  Client Function - looq.lookProductCode
#-----------------------------------------------------------------------------#
looq.lookProductCode <- function(par){
  
  plu <- looq.lookTag("$plu",par,c())
  ean <- looq.lookTag("$ean",par,c())
  #pluB <- looq.lookTag("pluB",par$`$itenCode`,c())
  
  #provisorio
  if(length(ean) > 0) ean <- c(2120)
  
  plu <- c(
    plu
    ,ean
    #,looq.client.convertEanToPLU(ean)
    #,looq.client.convertPluBToPlu(pluB)
  )
  unique(plu)
}

# par<-list(
#   "$itenCode"=list("plu"=c(1,2,3,4))
# )
# looq.lookProductCode(par)

#-----------------------------------------------------------------------------#
#---- Client Function - Same Store Sales - 
#-----------------------------------------------------------------------------#
client.getSSS <- function(dtIni, dtFim){
  dtIni <- as.Date(dtIni)
  dtFim <- as.Date(dtFim)
  
  conn = looq.conn("looqdata")
  sql <- paste(
    "
    SELECT
    STORE_CODE
    ,START_DATE
    ,END_DATE
    FROM looqdata.data_store_cad
    where 1=1
    order by 2
    "
  )
  
  r <- looq.sqlExecute(conn, sql,list(dtIni))
  r$data$START_DATE <- as.Date(r$data$START_DATE)
  r$data$END_DATE <- as.Date(r$data$END_DATE)
  
  #START DATE CASE
  r$data <- r$data[r$data$START_DATE < dtIni - 365,]
  
  #END DATE CASE
  r$data <- r$data[is.na(r$data$END_DATE)| r$data$END_DATE > dtFim,]
  
  #Returning Store Codes
  r$data$STORE_CODE
}

#get.sss('2012-10-02', '2013-11-01')

#-----------------------------------------------------------------------------#
#----Client Function - adjustDateIntervals
#-----------------------------------------------------------------------------#
client.getBetterWeekDayAdjustment <- function(dt1, dt2){
  d <- as.numeric(as.Date(dt2) - as.Date(dt1)) %% 7  
  if(d >= 4){
    d - 7 
  } else {
    d  
  }
}
#getBetterWeekDayAdjustment("2016-11-01", "2016-11-08")

client.adjustDateIntervals <- function(dateList){
  dateList <- lapply(dateList, as.Date)
  dt1 <- dateList[[1]]
  dt2 <- dateList[[2]]
  weekDayAdj <- client.getBetterWeekDayAdjustment(dt1[1], dt2[1])
  if(weekDayAdj != 0) {
    dt1 <- (dt1 + weekDayAdj)  
  }
  
  delta1 <- as.numeric(dt1[2]-dt1[1])
  delta2 <- as.numeric(dt2[2]-dt2[1])
  if(delta1 != delta2){
    totalDayAdjust <- (delta2 - delta1)
    dt1[2] <- (dt1[2] + totalDayAdjust)
  }
  
  list(dt1, dt2)
}

#adjustDateIntervals(list(c("2015-11-01", "2015-11-30"),c("2016-11-01", "2016-11-30")))
#adjustDateIntervals(list(c("2016-10-01", "2016-10-30"),c("2016-11-01", "2016-11-30")))
#adjustDateIntervals(list(c("2016-11-01", "2016-11-07"),c("2016-10-01", "2016-10-07")))

#-----------------------------------------------------------------------------#
#----Client Function - getUserStores
#-----------------------------------------------------------------------------#
client.userStores <- function(stores){
    
    # Query que irá rodar no banco de dados e retorna o nível do usuério
    sql.cargo <- paste("
                       SELECT DISTINCT DS_SGRTBA_NVL
                       FROM PRAPLBIT.T_SGR_TBA
                       WHERE 1=1
                       AND CD_SGRTBA_USR_TBA = `1`
                       ")
    
    sql.lojas <- paste("
                       SELECT CD_SGRTBA_FIL
                       FROM PRAPLBIT.T_SGR_TBA
                       WHERE 1=1
                       AND CD_SGRTBA_USR_TBA = `1`
                       ")
    
    # Cria uma looq.objTable e armazena os dados da query em r$data
    # O parâmetro da query é passado em uma lista, dentro de looq.sqlExecute
    cargo <- looq.sqlExecute("db2_prdcr", sql.cargo, list(looq.userLogin()))$data$DS_SGRTBA_NVL
    if(length(cargo) == 0) return ("Sem acesso ao sistema")
    # Se o usuário for corporativo não buscar as lojas
    if(cargo == "CORPORATIVO") {
        filiais <- stores
    } else {
        dados <- as.integer(looq.sqlExecute("db2_prdcr", sql.lojas, list(looq.userLogin()))$data$CD_SGRTBA_FIL)
        # Caso não especifique uma loja, retorna todas as disponíveis para o usuário
        # Se especificado, verifica se o usuário possui acesso às lojas especificadas
        if(is.null(dados)) return("Usuário não possui lojas cadastradas") else {
            if(is.null(stores)) {
                filiais <- dados
            } else {
                filiais <- intersect(stores, dados)
                if(length(filiais) == 0) return("Sem acesso à(s) loja(s) solicitada(s)")
            }
        }
    }
    filiais
}

#client.userStores(c())

#-----------------------------------------------------------------------------#
#----Client Function - getUserStores
#-----------------------------------------------------------------------------#
client.stores <- function(store = c(), user = looq.userId()){
     
     sql <- "SELECT *
             FROM looqdata.user_store
             WHERE 1=1
               AND userId = `1`"
     
     stores <- looq.sqlExecute("looqdata", sql, list(user))
     
     storeList <- stores$data
     
     if(nrow(storeList) == 0) return ("Sem acesso ao sistema")
     
     if(is.na(storeList$userDefaultStore)) {
          return(store)
     } else {
          
          if(storeList$defaultRestrict) {
               
               if(!is.null(store)){
                    storeList <- intersect(store, as.list(strsplit(storeList$userDefaultStore, ";")[[1]]))
               } else {
                    storeList <- as.list(strsplit(storeList$userDefaultStore, ";"))
               }
               if(length(storeList) == 0) return("Sem acesso à loja especificada")
               
          } else return(as.list(strsplit(storeList$userDefaultStore, ";")))
          
          storeList

     }
}
#client.stores(1,1)
